import { useMemo, useState } from 'react'
import { Button, Select, Space, Table, Tag, Tooltip, Typography } from 'antd'
import type { ColumnsType } from 'antd/es/table'
import dayjs from 'dayjs'
import { DownloadOutlined } from '@ant-design/icons'
import type { TradeLogItem } from '../../api/types'
import { fmtMoney, fmtNum, pnlColor } from '../../utils/format'

const TRADE_TYPES = ['开仓', '加仓', '减仓', '做T', '止损', '止盈', '清仓']

const TYPE_TAG_COLOR: Record<string, string> = {
  '开仓': 'red',
  '加仓': 'orange',
  '做T': 'purple',
  '止损': 'green',
  '止盈': 'cyan',
  '减仓': 'lime',
  '清仓': 'default'
}

/** 做T机制标签（T_REFACTOR：t_mode 字段，仅做T相关交易携带） */
const TMODE_LABEL: Record<string, string> = {
  grid: '网格',
  discipline: '纪律',
  time: '时点',
  off: '关'
}

/** 库存组归属标签（tag 字段：这笔交易属于哪个组——开仓组即底仓） */
const TAG_LABEL: Record<string, string> = {
  '开仓': '底仓',
  '加仓': '加仓',
  '做T': '做T',
  '减仓': '减仓'
}

const TAG_COLOR: Record<string, string> = {
  '做T': 'purple'
}

/** 行的库存组归属：卖出用 tag（引擎落盘），买入 tag 未落日志但 type 即组性质
 *  （开仓买入→底仓组/加仓买入→加仓组/做T买入→做T组），确定性回填 */
const rowTag = (t: TradeLogItem): string | undefined => {
  if (t.tag) return TAG_LABEL[t.tag] ?? t.tag
  if (t.side === 'buy') return TAG_LABEL[t.type]
  return undefined
}

export default function TradeLogTab({ trades }: { trades: TradeLogItem[] }) {
  const [typeFilter, setTypeFilter] = useState<string>('all')
  const [groupFilter, setGroupFilter] = useState<string>('all')
  const [sideFilter, setSideFilter] = useState<string>('all')
  const [codeFilter, setCodeFilter] = useState<string>('all')

  // 交易涉及的全部股票（代码+名称，去重，按代码排序）
  const stockOptions = useMemo(() => {
    const m = new Map<string, string>()
    for (const t of trades) m.set(t.code, t.name || t.code)
    return [...m.entries()]
      .sort((a, b) => a[0].localeCompare(b[0]))
      .map(([code, name]) => ({ value: code, label: `${code} ${name}` }))
  }, [trades])

  const filtered = useMemo(
    () =>
      trades.filter((t) => {
        // 类型筛选：做T按“库存组”口径命中（type=做T 的订单性质卖出 或 tag=做T 的库存组卖出），
        // 否则做T组库存被清仓/止损/减仓带走时按 type 筛会漏，做T统计偏小；其余类型仍按 type 精确匹配
        const typeHit =
          typeFilter === 'all' ||
          t.type === typeFilter ||
          (typeFilter === '做T' && t.tag === '做T')
        const groupHit = groupFilter === 'all' || rowTag(t) === groupFilter
        return (
          (codeFilter === 'all' || t.code === codeFilter) &&
          typeHit &&
          groupHit &&
          (sideFilter === 'all' || t.side === sideFilter)
        )
      }),
    [trades, codeFilter, typeFilter, groupFilter, sideFilter]
  )

  // 每笔交易成交后该股票的剩余持仓量（按交易时间顺序累计，过滤不影响数值）
  const remainByTrade = useMemo(() => {
    const map = new Map<number, number>()
    const cur = new Map<string, number>()
    for (const t of [...trades].sort((a, b) => a.trade_id - b.trade_id)) {
      const before = cur.get(t.code) ?? 0
      const after = t.side === 'buy' ? before + t.volume : before - t.volume
      map.set(t.trade_id, after)
      cur.set(t.code, after)
    }
    return map
  }, [trades])

  const exportCsv = () => {
    const headers = ['trade_id', '时间', '代码', '名称', '方向', '价格', '数量', '剩余持仓', '金额', '手续费', '类型', '组别', 'T模式', '理由', '平仓盈亏']
    const rows = filtered.map((t) => [
      t.trade_id,
      t.time,
      t.code,
      t.name,
      t.side,
      t.price,
      t.volume,
      remainByTrade.get(t.trade_id) ?? '',
      t.amount,
      t.fee,
      t.type,
      rowTag(t) ?? '',
      t.t_mode ?? '',
      t.reason ?? '',
      t.pnl ?? ''
    ])
    const escape = (v: unknown) => `"${String(v ?? '').replace(/"/g, '""')}"`
    const csv =
      '\uFEFF' + [headers.join(','), ...rows.map((r) => r.map(escape).join(','))].join('\n')
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `trade_log_${dayjs().format('YYYYMMDD_HHmmss')}.csv`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const columns: ColumnsType<TradeLogItem> = [
    { title: '#', dataIndex: 'trade_id', width: 44 },
    {
      // 无滚动条总宽预算：时间显示缩短为 YY-MM-DD HH:mm（秒位无意义），悬浮看全
      title: '时间',
      dataIndex: 'time',
      width: 116,
      render: (v: string) => {
        const s = v.length > 10 ? dayjs(v).format('YY-MM-DD HH:mm') : v
        return (
          <Tooltip title={v} placement="topLeft">
            <span>{s}</span>
          </Tooltip>
        )
      }
    },
    { title: '代码', dataIndex: 'code', width: 66 },
    { title: '名称', dataIndex: 'name', width: 72, ellipsis: true },
    {
      title: '方向',
      dataIndex: 'side',
      width: 58,
      render: (v: 'buy' | 'sell') =>
        v === 'buy' ? <Tag color="red">买入</Tag> : <Tag color="green">卖出</Tag>
    },
    {
      title: '段',
      dataIndex: 'seg',
      width: 44,
      render: (v: number | undefined) =>
        v != null ? <Tooltip title="动态选股段号（滚动重选）"><Tag color="geekblue">S{v}</Tag></Tooltip> : '-'
    },
    {
      title: '价格',
      dataIndex: 'price',
      width: 78,
      align: 'right',
      render: (v: number) => fmtNum(v, 3)
    },
    {
      title: '数量',
      dataIndex: 'volume',
      width: 76,
      align: 'right',
      render: (v: number) => v.toLocaleString('zh-CN')
    },
    {
      title: '剩余持仓',
      width: 76,
      align: 'right',
      render: (_v, t) => {
        const r = remainByTrade.get(t.trade_id)
        return r === undefined ? '-' : <span>{r.toLocaleString('zh-CN')}</span>
      }
    },
    {
      title: '金额',
      dataIndex: 'amount',
      width: 96,
      align: 'right',
      render: (v: number) => fmtMoney(v)
    },
    {
      title: '手续费',
      dataIndex: 'fee',
      width: 74,
      align: 'right',
      render: (v: number) => fmtMoney(v)
    },
    {
      title: '类型',
      dataIndex: 'type',
      width: 92,
      render: (v: string, t) => (
        <Space size={4} wrap>
          <Tag color={TYPE_TAG_COLOR[v] ?? 'default'}>{v}</Tag>
          {t.t_mode && <Tag color="geekblue">{TMODE_LABEL[t.t_mode] ?? t.t_mode}</Tag>}
        </Space>
      )
    },
    {
      // 组别=库存归属（tag）：卖出用引擎落盘 tag，买入按 type 回填（开仓→底仓/加仓/做T）
      title: '组别',
      dataIndex: 'tag',
      width: 60,
      render: (_v, t) => {
        const g = rowTag(t)
        if (!g) return '-'
        return <Tag color={TAG_COLOR[g] ?? 'default'}>{g}</Tag>
      }
    },
    {
      // 理由固定宽度多行展开：不设 width 的自适应列会被固定列挤压成省略号；
      // 3 行 clamp 尽量放下全文，超长悬浮 Tooltip 兜底
      title: '理由',
      dataIndex: 'reason',
      width: 200,
      render: (v: string | null) =>
        v ? (
          <Tooltip title={v} placement="topLeft">
            <span
              style={{
                display: '-webkit-box',
                WebkitLineClamp: 3,
                WebkitBoxOrient: 'vertical',
                overflow: 'hidden',
                wordBreak: 'break-all',
                whiteSpace: 'normal'
              }}
            >
              {v}
            </span>
          </Tooltip>
        ) : (
          '-'
        )
    },
    {
      title: '平仓盈亏',
      dataIndex: 'pnl',
      width: 88,
      align: 'right',
      render: (v: number | null) =>
        v === null || v === undefined ? '-' : <span style={{ color: pnlColor(v) }}>{fmtMoney(v)}</span>
    }
  ]

  return (
    <div>
      <Space style={{ marginBottom: 12 }}>
        <Typography.Text>股票：</Typography.Text>
        <Select
          value={codeFilter}
          onChange={setCodeFilter}
          style={{ width: 220 }}
          showSearch
          optionFilterProp="label"
          options={[{ value: 'all', label: '全部' }, ...stockOptions]}
        />
        <Typography.Text>类型：</Typography.Text>
        <Select
          value={typeFilter}
          onChange={setTypeFilter}
          style={{ width: 120 }}
          options={[
            { value: 'all', label: '全部' },
            ...TRADE_TYPES.map((t) => ({ value: t, label: t }))
          ]}
        />
        <Typography.Text>组别：</Typography.Text>
        <Select
          value={groupFilter}
          onChange={setGroupFilter}
          style={{ width: 100 }}
          options={[
            { value: 'all', label: '全部' },
            ...Object.entries(TAG_LABEL).map(([v, label]) => ({ value: v, label }))
          ]}
        />
        <Typography.Text>方向：</Typography.Text>
        <Select
          value={sideFilter}
          onChange={setSideFilter}
          style={{ width: 100 }}
          options={[
            { value: 'all', label: '全部' },
            { value: 'buy', label: '买入' },
            { value: 'sell', label: '卖出' }
          ]}
        />
        <Button icon={<DownloadOutlined />} onClick={exportCsv}>
          导出CSV
        </Button>
        <Typography.Text type="secondary">共 {filtered.length} 笔</Typography.Text>
      </Space>
      <Table<TradeLogItem>
        rowKey="trade_id"
        dataSource={filtered}
        columns={columns}
        size="small"
        scroll={{ x: 1240 }}
        rowClassName={(t) => (rowTag(t) === '做T' ? 't-group-row' : '')}
        pagination={{ pageSize: 50, showSizeChanger: true, showTotal: (t) => `共 ${t} 笔` }}
      />
    </div>
  )
}
