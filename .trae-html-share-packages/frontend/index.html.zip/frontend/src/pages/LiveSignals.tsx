import { useCallback, useEffect, useRef, useState } from 'react'
import {
  Alert, Button, Card, Checkbox, Col, Collapse, Form, Input, InputNumber, Modal,
  Popconfirm, Progress, Row, Select, Space, Statistic, Switch, Table, Tag,
  Typography, message
} from 'antd'
import {
  CheckCircleOutlined, CloseCircleOutlined, DeleteOutlined, NotificationOutlined,
  PlayCircleOutlined, PlusOutlined, SaveOutlined, SyncOutlined, ThunderboltOutlined
} from '@ant-design/icons'
import type { ColumnsType } from 'antd/es/table'
import type {
  BacktestTemplateItem, IntradayCodeStatus, IntradayRunResult, IntradayStatus,
  LiveConfig, LivePosition, LiveSignalItem, ReadinessResult, ShadowStats,
  SlippageResult, TaskStatus, TemplateApplyPreview
} from '../api/types'
import {
  addLiveFill, applyTemplateToLive, getIntradayStatus, getLiveSummary,
  getReadiness, getShadowStats, getSlippage, getTemplates, resetLiveData,
  runIntraday, runMorning, runPostclose, saveLiveConfig, setLiveSignalStatus,
  syncLivePositions
} from '../api/client'
import { useTaskProgress } from '../hooks/useTaskProgress'
import TaskStopButton from '../components/TaskStopButton'
import { fmtMoney } from '../utils/format'

const STYPE_TAG: Record<string, string> = {
  开仓: 'red', 加仓: 'orange', 做T: 'purple', 止损: 'green',
  止盈: 'cyan', 减仓: 'lime', 清仓: 'default', 预警: 'volcano',
  池子: 'geekblue', 对账: 'blue'
}

const RANK_KEY_OPTS = [
  { value: 'score', label: '累计强度（score）' },
  { value: 'accel', label: '加速度（accel）' },
  { value: 'fresh', label: '金叉新鲜（fresh）' },
  { value: 'mom_gap', label: '短中差值（mom_gap）' }
]

const INDEX_OPTS = [
  { value: 'zz500', label: '中证500' },
  { value: 'hs300', label: '沪深300' },
  { value: 'csi1000', label: '中证1000' },
  { value: 'kcb50', label: '科创50' }
]

const BOARD_OPTS = [
  { value: 'kcb', label: '科创板' },
  { value: 'cyb', label: '创业板' },
  { value: 'zxb', label: '中小板/主板' }
]

const T_MODE_OPTS = [
  { value: 'off', label: '关闭做T（off，M2 起步建议）' },
  { value: 'grid', label: '网格双止损（grid）' },
  { value: 'discipline', label: '回补纪律（discipline）' },
  { value: 'time', label: '时点规律T（time）' }
]

function statusTag(s: string) {
  if (s === '已成交') return <Tag color="success">已成交</Tag>
  if (s === '已忽略') return <Tag>已忽略</Tag>
  if (s === '已过期') return <Tag color="default">已过期</Tag>
  if (s === '信息') return <Tag color="blue">信息</Tag>
  return <Tag color="processing">待执行</Tag>
}

function staleDays(asOf: string | null | undefined): number {
  if (!asOf) return 0
  return Math.floor((Date.now() - new Date(asOf).getTime()) / 86400000)
}

/** 回填参考股数预填：买=建议金额/参考价（100股取整）；
 * 卖=按虚拟持仓推（清仓/止损=全部持仓，减仓/做T=按 extra 比例）。<100 股不预填 */
function refFillVolume(s: LiveSignalItem, positions: LivePosition[]): number | null {
  const side = ['开仓', '加仓'].includes(s.stype) ? 'buy' : 'sell'
  const lot = (v: number): number | null =>
    v >= 100 ? Math.floor(v / 100) * 100 : null
  if (side === 'buy') {
    if (!s.ref_price || !s.suggest_amount) return null
    return lot(s.suggest_amount / s.ref_price)
  }
  const pos = positions.find((p) => p.code === s.code)
  if (!pos || pos.volume <= 0) return null
  const extra = (s.extra || {}) as { reduce_pct?: number; t_ratio?: number }
  if (s.stype === '减仓' && extra.reduce_pct) {
    return lot((pos.volume * extra.reduce_pct) / 100)
  }
  if (s.stype === '做T' && extra.t_ratio) {
    return lot((pos.volume * extra.t_ratio) / 100)
  }
  return lot(pos.volume)   // 止损/清仓 = 全部持仓
}

export default function LiveSignals() {
  const [summary, setSummary] = useState<Awaited<ReturnType<typeof getLiveSummary>> | null>(null)
  const [loading, setLoading] = useState(false)
  const [premarketLoading, setPremarketLoading] = useState(false)
  const [fillTarget, setFillTarget] = useState<LiveSignalItem | null>(null)
  const [fillPrice, setFillPrice] = useState<number | null>(null)
  const [fillVolume, setFillVolume] = useState<number | null>(null)
  const [fillFee, setFillFee] = useState<number | null>(null)
  const [cfg, setCfg] = useState<LiveConfig | null>(null)
  const [cfgSaving, setCfgSaving] = useState(false)
  const [morningLoading, setMorningLoading] = useState(false)
  const [intradayStatus, setIntradayStatus] = useState<IntradayStatus | null>(null)
  const [intradayRun, setIntradayRun] = useState<IntradayRunResult | null>(null)
  const [intradayLoading, setIntradayLoading] = useState(false)
  const [autoPoll, setAutoPoll] = useState(false)
  const [showAllCodes, setShowAllCodes] = useState(false)
  const [postcloseLoading, setPostcloseLoading] = useState(false)
  const [slip, setSlip] = useState<SlippageResult | null>(null)
  const [shadow, setShadow] = useState<ShadowStats | null>(null)
  const [ready, setReady] = useState<ReadinessResult | null>(null)
  const loadedReports = useRef<Set<string>>(new Set())

  const loadStatus = useCallback(() => {
    getIntradayStatus().then(setIntradayStatus).catch(() => {})
  }, [])

  useEffect(() => { loadStatus() }, [loadStatus])

  useEffect(() => {
    if (!autoPoll) return
    let inFlight = false
    const t = setInterval(async () => {
      if (inFlight) return   // 上一轮未返回，跳过本轮（防请求堆积）
      inFlight = true
      try {
        await runIntraday()
      } catch { /* 断流由后端熔断推送告警 */ } finally {
        inFlight = false
      }
      loadStatus()
    }, 60_000)
    return () => clearInterval(t)
  }, [autoPoll, loadStatus])

  const loadReport = (key: string) => {
    if (loadedReports.current.has(key)) return
    loadedReports.current.add(key)
    if (key === 'slip') getSlippage().then(setSlip).catch(() => {})
    if (key === 'shadow') getShadowStats().then(setShadow).catch(() => {})
    if (key === 'ready') getReadiness().then(setReady).catch(() => {})
  }

  const onCollapseChange = (keys: string | string[]) => {
    const ks = Array.isArray(keys) ? keys : [keys]
    ks.forEach(loadReport)
  }

  const refresh = useCallback(async (force = false) => {
    setLoading(true)
    try {
      const s = await getLiveSummary()
      setSummary(s)
      // force=true：以服务端值为准重刷配置卡（模板注入后必须如此，
      // 否则 state 停留注入前旧值，随后保存会把刚注入的模板值静默冲掉）
      setCfg((prev) => (force ? s.config : (prev ?? s.config)))
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { refresh() }, [refresh])

  // 盘前编排任务进度（提交后在本页直接跟踪，无需跳转）
  const [morningTaskId, setMorningTaskId] = useState<string | null>(null)
  const onMorningDone = useCallback((status: TaskStatus,
                                     full: { message: string } | null) => {
    if (status === 'success') {
      message.success('盘前流程已完成并推送，信号/池子已落库')
      refresh()
      loadStatus()
    } else if (status === 'failed') {
      message.error(`盘前流程失败：${full?.message || '未知错误'}`)
    } else if (status === 'cancelled') {
      message.warning('盘前流程已停止（数据更新可能部分完成，可重新发起）')
      refresh()
    }
    setMorningTaskId(null)
  }, [refresh, loadStatus])
  const morningTask = useTaskProgress(morningTaskId, onMorningDone)

  const [postcloseTaskId, setPostcloseTaskId] = useState<string | null>(null)
  const onPostcloseDone = useCallback((status: TaskStatus,
                                       full: { message: string } | null) => {
    if (status === 'success') {
      message.success('盘后流程完成：分钟线已落库，对账卡已推送')
      refresh()
      loadStatus()
    } else if (status === 'failed') {
      message.error(`盘后流程失败：${full?.message || '未知错误'}`)
    } else if (status === 'cancelled') {
      message.warning('盘后流程已停止')
      refresh()
    }
    setPostcloseTaskId(null)
  }, [refresh, loadStatus])
  const postcloseTask = useTaskProgress(postcloseTaskId, onPostcloseDone)

  const onFill = async () => {
    if (!fillTarget || !fillPrice || !fillVolume) return
    try {
      await addLiveFill({
        signal_id: fillTarget.id,
        code: fillTarget.code || '',
        side: ['开仓', '加仓'].includes(fillTarget.stype) ? 'buy' : 'sell',
        fill_price: fillPrice, fill_volume: fillVolume,
        fee: fillFee ?? undefined
      })
      message.success(fillFee != null
        ? '成交已回填，虚拟持仓已更新（手续费按手填值）'
        : '成交已回填，手续费已按费率自动计算并摊入成本')
      setFillTarget(null)
      await refresh()
    } catch (err) {
      message.error((err as { response?: { data?: { detail?: string } } })
        ?.response?.data?.detail || '回填失败')
    }
  }

  const onIgnore = async (s: LiveSignalItem) => {
    await setLiveSignalStatus(s.id, '已忽略')
    await refresh()
  }

  // ---- 回测模板 -> 实盘配置注入（TEMPLATE_INJECT） ----
  const [tplOpen, setTplOpen] = useState(false)
  const [tplList, setTplList] = useState<BacktestTemplateItem[]>([])
  const [tplId, setTplId] = useState<number | null>(null)
  const [tplPreview, setTplPreview] = useState<TemplateApplyPreview | null>(null)
  const [tplCapital, setTplCapital] = useState(false)
  const [tplApplying, setTplApplying] = useState(false)

  const openTplModal = async () => {
    setTplOpen(true)
    setTplId(null)
    setTplPreview(null)
    setTplCapital(false)
    try {
      setTplList(await getTemplates())
    } catch {
      message.error('模板列表加载失败')
    }
  }

  const loadTplPreview = useCallback(
    async (id: number | null, capital: boolean) => {
      if (!id) { setTplPreview(null); return }
      try {
        setTplPreview(await applyTemplateToLive({
          template_id: id, dry_run: true, apply_capital: capital
        }))
      } catch (err) {
        setTplPreview(null)
        message.error((err as { response?: { data?: { detail?: string } } })
          ?.response?.data?.detail || '注入预览失败')
      }
    }, [])

  const onTplApply = async () => {
    if (!tplId) return
    setTplApplying(true)
    try {
      await applyTemplateToLive({
        template_id: tplId, dry_run: false, apply_capital: tplCapital
      })
      message.success('模板配置已注入实盘，下次盘前流程生效')
      setTplOpen(false)
      await refresh(true)
    } catch (err) {
      message.error((err as { response?: { data?: { detail?: string } } })
        ?.response?.data?.detail || '注入失败')
    } finally {
      setTplApplying(false)
    }
  }

  const [syncOpen, setSyncOpen] = useState(false)
  const [syncForm] = Form.useForm()
  const openSync = () => {
    if (!summary) return
    syncForm.setFieldsValue({
      positions: summary.positions.map((p: LivePosition) => ({
        code: p.code, name: p.name, volume: p.volume,
        cost_price: p.cost_price, open_day: p.open_day
      }))
    })
    setSyncOpen(true)
  }

  const onSync = async () => {
    try {
      const { positions } = await syncForm.validateFields()
      const rows = (positions ?? []).filter(
        (p: { code?: string }) => p.code && String(p.code).trim())
      const commit = async () => {
        await syncLivePositions(rows)
        message.success(`已按提交列表重建虚拟持仓（${rows.length} 只）`)
        setSyncOpen(false)
        await refresh()
      }
      if (rows.length === 0) {
        Modal.confirm({
          title: '提交空列表 = 按空仓校准（清空全部虚拟持仓）',
          content: '如果只是想核对持仓，请点取消后在表格中填写券商实际持仓。',
          okText: '确认清空', okButtonProps: { danger: true }, cancelText: '取消',
          onOk: commit
        })
        return
      }
      await commit()
    } catch (err) {
      if (err && typeof err === 'object' && 'errorFields' in err) return
      message.error((err as { response?: { data?: { detail?: string } } })
        ?.response?.data?.detail || '校准失败')
    }
  }

  const onSaveCfg = async () => {
    if (!cfg) return
    setCfgSaving(true)
    try {
      await saveLiveConfig(cfg)
      message.success('配置已保存，下次盘前流程生效')
      await refresh()
    } finally {
      setCfgSaving(false)
    }
  }

  const onReset = async () => {
    await resetLiveData()
    setShowAllCodes(false)
    message.success('已清空信号数据（流程参数配置保留）')
    await refresh()
    loadStatus()
  }

  const onMorning = async (updateData: boolean, force = false) => {
    setMorningLoading(true)
    try {
      const r = await runMorning(updateData, force)
      setMorningTaskId(r.task_id)
      message.success(
        `盘前编排任务已提交（${r.task_id}）${updateData ? '：先做全市场日线增量更新（约数分钟），' : ''}` +
        '完成后自动执行盘前流程并推送，进度见下方')
    } catch (err) {
      const e = err as { response?: { status?: number; data?: { detail?: string } } }
      if (!force && e?.response?.status === 409) {
        Modal.confirm({
          title: '今日盘前流程已执行',
          content: e.response.data?.detail || '今天已跑过盘前流程，确定强制重跑并再次推送吗？',
          okText: '强制重跑',
          cancelText: '取消',
          onOk: () => onMorning(updateData, true)
        })
        return
      }
      message.error(e?.response?.data?.detail || '盘前编排提交失败')
    } finally {
      setMorningLoading(false)
    }
  }

  const onIntraday = async () => {
    setIntradayLoading(true)
    try {
      const r = await runIntraday()
      setIntradayRun(r)
      if (r.skipped) {
        message.info(r.skipped)
      } else if (r.signals.length) {
        message.success(
          `本轮 ${r.signals.length} 条信号（喂入 ${r.fed_bars} 根完成 bar），` +
          `推送${r.pushed ? '成功' : '未配置飞书（仅落库）'}`)
      } else {
        message.info(`本轮无信号（喂入 ${r.fed_bars} 根完成 bar）`)
      }
      loadStatus()
      await refresh()
    } catch (err) {
      message.error((err as { response?: { data?: { detail?: string } } })
        ?.response?.data?.detail || '盘中轮询失败')
    } finally {
      setIntradayLoading(false)
    }
  }

  const onPostclose = async (force = false) => {
    setPostcloseLoading(true)
    try {
      const r = await runPostclose(force)
      setPostcloseTaskId(r.task_id)
      message.success(`盘后任务已提交（${r.task_id}），完成后自动推送对账卡，进度见下方`)
    } catch (err) {
      const e = err as { response?: { status?: number; data?: { detail?: string } } }
      if (!force && e?.response?.status === 409) {
        Modal.confirm({
          title: '今日盘后流程已执行',
          content: e.response.data?.detail || '今天已跑过盘后对账，确定强制重跑并再次推送吗？',
          okText: '强制重跑',
          cancelText: '取消',
          onOk: () => onPostclose(true)
        })
        return
      }
      message.error(e?.response?.data?.detail || '盘后流程提交失败')
    } finally {
      setPostcloseLoading(false)
    }
  }

  const signalCols: ColumnsType<LiveSignalItem> = [
    {
      title: '类型', dataIndex: 'stype', width: 80,
      render: (v: string) => <Tag color={STYPE_TAG[v] ?? 'default'}>{v}</Tag>
    },
    { title: '代码', dataIndex: 'code', width: 90, render: (v) => v || '-' },
    { title: '名称', dataIndex: 'name', width: 110, ellipsis: true },
    { title: '理由', dataIndex: 'reason' },   // 完整展示不截断：理由含代码等信息需可复制
    {
      title: '建议金额', dataIndex: 'suggest_amount', width: 110, align: 'right',
      render: (v) => (v != null ? fmtMoney(v) : '-')
    },
    {
      title: '参考价', dataIndex: 'ref_price', width: 90, align: 'right',
      render: (v) => (v != null ? v.toFixed(3) : '-')
    },
    {
      title: '状态', dataIndex: 'status', width: 90,
      render: (v: string) => statusTag(v)
    },
    { title: '时间', dataIndex: 'ts', width: 160 },
    {
      title: '操作', width: 150,
      render: (_v, s) =>
        s.status === '待执行' && s.code ? (
          <Space size={4}>
            <Button size="small" type="primary" onClick={() => {
              setFillTarget(s)
              setFillPrice(s.ref_price)
              setFillVolume(refFillVolume(s, summary?.positions ?? []))
              setFillFee(null)
            }}>回填</Button>
            <Button size="small" onClick={() => onIgnore(s)}>忽略</Button>
          </Space>
        ) : '-'
    }
  ]

  const posCols: ColumnsType<LivePosition> = [
    { title: '代码', dataIndex: 'code', width: 90 },
    { title: '名称', dataIndex: 'name', width: 110, ellipsis: true },
    {
      title: '数量', dataIndex: 'volume', width: 100, align: 'right',
      render: (v) => v.toLocaleString('zh-CN')
    },
    {
      title: '成本价', dataIndex: 'cost_price', width: 90, align: 'right',
      render: (v) => v?.toFixed(3)
    },
    {
      title: '现价', dataIndex: 'last_price', width: 90, align: 'right',
      render: (v) => (v != null ? v.toFixed(3) : '-'),
      onCell: (r) => ({ title: r.last_ts ? `价格时点 ${r.last_ts}` : '尚未轮询到现价（执行盘中轮询/盘后流程后更新）' })
    },
    {
      title: '市值', width: 110, align: 'right',
      render: (_, r) => (r.last_price != null
        ? (r.last_price * r.volume).toLocaleString('zh-CN', { maximumFractionDigits: 0 })
        : '-')
    },
    {
      title: '浮盈', width: 120, align: 'right',
      render: (_, r) => {
        if (r.last_price == null) return <span style={{ color: '#999' }}>-</span>
        const pnl = (r.last_price - r.cost_price) * r.volume
        const pct = r.cost_price > 0 ? (r.last_price / r.cost_price - 1) * 100 : 0
        const color = pnl > 0 ? '#cf1322' : pnl < 0 ? '#3f8600' : '#666'
        return <span style={{ color, fontWeight: 500 }}>
          {pnl >= 0 ? '+' : ''}{pnl.toLocaleString('zh-CN', { maximumFractionDigits: 0 })}
          <span style={{ fontSize: 12, marginLeft: 4 }}>
            ({pct >= 0 ? '+' : ''}{pct.toFixed(2)}%)
          </span>
        </span>
      }
    },
    {
      title: '开仓日', dataIndex: 'open_day', width: 110,
      render: (v) => v || '-'
    }
  ]

  const intradayCols: ColumnsType<IntradayCodeStatus> = [
    { title: '代码', dataIndex: 'code', width: 90 },
    { title: '名称', dataIndex: 'name', width: 110, ellipsis: true },
    {
      title: '现价', dataIndex: 'price', width: 90, align: 'right',
      render: (v) => (v != null ? v.toFixed(3) : '-')
    },
    {
      title: '来源', dataIndex: 'in_pool', width: 90,
      render: (v, r) => (
        <Space size={4}>
          {r.held && <Tag color="orange">持仓</Tag>}
          {v && <Tag color="geekblue">池子</Tag>}
          {!r.held && !v && <Tag>跟踪</Tag>}
        </Space>
      )
    },
    {
      title: '状态机', width: 160,
      render: (_v, r) => (
        <Typography.Text style={{ fontSize: 12 }}>
          {r.opened ? (r.full ? `满配·已加${r.adds_done}` : '试仓') : '未持仓'}
          {r.exit_stage > 0 ? `｜退出中(${r.exit_stage})` : ''}
        </Typography.Text>
      )
    },
    {
      title: '喂bar游标', dataIndex: 'last_bar', width: 150,
      render: (v) => <Typography.Text style={{ fontSize: 12 }}>{v || '-'}</Typography.Text>
    }
  ]

  const pool = summary?.pool
  const stale = staleDays(pool?.as_of)
  const numCell = (v: number | null | undefined, onChange: (v: number | null) => void,
                   step: number, min: number) => (
    <InputNumber style={{ width: '100%' }} value={v ?? undefined}
      step={step} min={min}
      onChange={(n) => { if (n !== null) onChange(n) }}
      onBlur={(e) => {
        // 失焦兜底：antd 受控 InputNumber 手打值在输入法/失焦竞态下可能丢失
        // onChange，导致受控值弹回默认（上下按钮路径不受影响）——以 DOM 实际
        // 文本为准补交一次，与 onChange 幂等
        const n = parseFloat(
          String((e.target as HTMLInputElement).value).replace(/,/g, ''))
        if (!Number.isNaN(n)) onChange(n)
      }} />
  )

  return (
    <Space direction="vertical" size="middle" style={{ width: '100%' }}>
      {stale > 4 && (
        <Alert
          type="warning" showIcon
          message={`行情数据截至 ${pool?.as_of}（滞后 ${stale} 天）`}
          description="盘前流程只读现有日线库、不自动拉数据。数据不完整会导致选股出现'幸存者偏差'（只有数据完整的票参选）。请先到数据管理页更新日线，再执行盘前流程。"
        />
      )}
      <Row gutter={16}>
        <Col span={6}>
          <Card size="small" loading={loading}>
            <Statistic title="池级 gate"
              value={pool?.gate_state ? '停开仓' : '正常'}
              valueStyle={{ fontSize: 20, color: pool?.gate_state ? '#cf1322' : '#3f8600' }} />
            <Typography.Text type="secondary" style={{ fontSize: 12 }}>
              健康度 {pool?.health_history?.slice(-1)[0]?.health ?? '-'}
            </Typography.Text>
          </Card>
        </Col>
        <Col span={6}>
          <Card size="small" loading={loading}>
            <Statistic title="当前池子" value={`${pool?.pool?.length ?? 0} 只`}
              valueStyle={{ fontSize: 20 }} />
            <Typography.Text type="secondary" style={{ fontSize: 12 }}>
              基准日 {pool?.as_of ?? '-'}｜候选域：{cfg?.auto_index?.length ? cfg.auto_index.join('+') : '全市场'}
            </Typography.Text>
          </Card>
        </Col>
        <Col span={6}>
          <Card size="small" loading={loading}>
            <Statistic title="虚拟持仓" value={`${summary?.positions?.length ?? 0} 只`}
              valueStyle={{ fontSize: 20 }} />
            <Typography.Text type="secondary" style={{ fontSize: 12 }}>
              空仓起始 {pool?.idle_start ?? '-'}
            </Typography.Text>
          </Card>
        </Col>
        <Col span={6}>
          <Card size="small" loading={loading}>
            <Statistic title="飞书推送"
              value={summary?.feishu_configured ? '已配置' : '未配置'}
              valueStyle={{ fontSize: 20,
                color: summary?.feishu_configured ? '#3f8600' : '#cf1322' }} />
            <Typography.Text type="secondary" style={{ fontSize: 12 }}>
              .env 的 FEISHU_WEBHOOK_URL
            </Typography.Text>
          </Card>
        </Col>
      </Row>

      <Card size="small" title="每日信号流程（盘前 → 盘中 → 盘后）"
        extra={
          <Space>
            <Button icon={<PlayCircleOutlined />} loading={morningLoading}
              onClick={() => onMorning(false)}>
              仅盘前（不拉数据）
            </Button>
            <Button type="primary" icon={<SyncOutlined />} loading={morningLoading}
              onClick={() => onMorning(true)}>
              盘前流程（自动拉数据）
            </Button>
            <Button icon={<ThunderboltOutlined />} loading={postcloseLoading}
              onClick={() => onPostclose()}>
              盘后落库与对账
            </Button>
          </Space>
        }>
        <Alert
          type="info" showIcon
          message={
            '盘前：日线增量更新（含完整性守卫）→ T-1 特征重算 → 池级 gate → 空仓重选 → 退出检查 → 飞书推送；' +
            '盘中：完成 bar → 状态机步进 → 风控前置 → 推送（下方控制台）；' +
            '盘后：分钟线落库 + 对账卡推送'}
          style={{ marginBottom: 8 }}
        />
        {summary?.signals?.length ? (
          <Alert
            type={summary.signals.some((s) => s.stype === '开仓') ? 'warning' : 'success'}
            showIcon icon={<NotificationOutlined />}
            message={`最近一次盘前产出 ${summary.signals.length} 条交易信号（见下方列表）`}
          />
        ) : (
          <Typography.Text type="secondary">尚未产生交易信号</Typography.Text>
        )}
        {(morningTaskId || postcloseTaskId) && (
          <div style={{ marginTop: 8 }}>
            {morningTaskId && (
              <div style={{ marginBottom: 4 }}>
                <Space size={8} wrap>
                  <Progress
                    percent={Math.round(morningTask.progress)}
                    size="small" status="active"
                    style={{ width: 220 }}
                    strokeColor={{ from: '#1677ff', to: '#36cfc9' }} />
                  <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                    盘前任务 {morningTaskId}｜{morningTask.message || '排队中...'}
                  </Typography.Text>
                  <TaskStopButton taskId={morningTaskId} />
                </Space>
              </div>
            )}
            {postcloseTaskId && (
              <div>
                <Space size={8} wrap>
                  <Progress
                    percent={Math.round(postcloseTask.progress)}
                    size="small" status="active"
                    style={{ width: 220 }}
                    strokeColor={{ from: '#faad14', to: '#fa8c16' }} />
                  <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                    盘后任务 {postcloseTaskId}｜{postcloseTask.message || '排队中...'}
                  </Typography.Text>
                  <TaskStopButton taskId={postcloseTaskId} />
                </Space>
              </div>
            )}
          </div>
        )}
      </Card>

      <Card
        size="small"
        title={
          <Space>
            <span>盘中信号机（M2）</span>
            <Tag color={intradayStatus?.session ? 'green' : 'default'}>
              {intradayStatus?.session ? '盘中时段' : '非交易时段'}
            </Tag>
            {intradayStatus && (
              <Tag color={intradayStatus.t_mode === 'off' ? 'default' : 'purple'}>
                t_mode={intradayStatus.t_mode}
              </Tag>
            )}
            {intradayStatus?.heartbeat?.alerted && (
              <Tag color="volcano">断流熔断中</Tag>
            )}
          </Space>
        }
        extra={
          <Space>
            <Button size="small" type="primary" icon={<ThunderboltOutlined />}
              loading={intradayLoading} onClick={onIntraday}>
              执行盘中轮询
            </Button>
            <Space size={4}>
              <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                自动(60秒)
              </Typography.Text>
              <Switch size="small" checked={autoPoll} onChange={setAutoPoll} />
            </Space>
          </Space>
        }>
        {(() => {
          const allCodes = intradayStatus?.codes ?? []
          const focusCodes = allCodes.filter(
            (c) => c.held || c.opened || c.exit_stage > 0)
          const reserve = allCodes.length - focusCodes.length
          if (!allCodes.length) {
            return <Table<IntradayCodeStatus>
              rowKey="code" size="small" dataSource={[]}
              columns={intradayCols} pagination={false}
              locale={{ emptyText: '无跟踪标的（先执行盘前流程生成池子）' }} />
          }
          return <>
            <Space size={8} style={{ marginBottom: 8 }}>
              <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                重点跟踪 {focusCodes.length} 只（持仓 / 状态机已开仓 / 衰退中）
                ｜池内候补 {reserve} 只（状态机持续监控，补位候选）
              </Typography.Text>
              {reserve > 0 && (
                <Button type="link" size="small" style={{ padding: 0 }}
                  onClick={() => setShowAllCodes(!showAllCodes)}>
                  {showAllCodes ? '收起候补' : '展开候补'}
                </Button>
              )}
            </Space>
            <Table<IntradayCodeStatus>
              rowKey="code" size="small"
              dataSource={showAllCodes ? allCodes : focusCodes}
              columns={intradayCols} pagination={false}
              locale={{ emptyText: '无重点跟踪标的' }} />
          </>
        })()}
        {intradayRun?.suspended?.length ? (
          <Alert type="warning" showIcon style={{ marginTop: 8 }}
            message="本轮拦截/暂停"
            description={intradayRun.suspended
              .map((w) => `${w.code}：${w.reason}`)
              .join('；')} />
        ) : null}
      </Card>

      <Card size="small" title="信号列表">
        <Table<LiveSignalItem>
          rowKey="id" size="small" loading={loading}
          dataSource={summary?.signals ?? []}
          columns={signalCols}
          pagination={{ pageSize: 20, showTotal: (t) => `共 ${t} 条` }}
          title={() => (
            <Popconfirm
              title="清空全部信号数据？"
              description="将删除：信号流水、成交回填、虚拟持仓、池子状态。流程参数配置保留。"
              okText="清空重来" okButtonProps={{ danger: true }}
              cancelText="取消"
              onConfirm={onReset}
            >
              <Button size="small" danger icon={<DeleteOutlined />}>
                清空重来
              </Button>
            </Popconfirm>
          )}
        />
      </Card>

      <Card size="small" title="虚拟持仓"
        extra={
          <Button size="small" icon={<SyncOutlined />} onClick={openSync}>
            对账校准（以券商实际持仓为准）
          </Button>
        }>
        <Table<LivePosition>
          rowKey="code" size="small" loading={loading}
          dataSource={summary?.positions ?? []}
          columns={posCols}
          pagination={false}
          locale={{ emptyText: '暂无虚拟持仓（回填买入成交后生成）' }}
        />
      </Card>

      <Modal open={syncOpen} forceRender
        title="对账校准：以券商实际持仓为准重建虚拟持仓"
        okText="按以上持仓重建" cancelText="取消"
        onCancel={() => setSyncOpen(false)} onOk={onSync} width={760}>
        <Alert type="info" showIcon style={{ marginBottom: 12 }}
          message="照券商 App 持仓逐行核对/修改；不需要的行点右侧删除；全部删除后提交 = 按空仓校准。重建只改虚拟账本，不影响信号流水与成交回填记录。" />
        <Form form={syncForm} initialValues={{ positions: [] }}>
          <Form.List name="positions">
            {(fields, { add, remove }) => (
              <>
                {fields.map(({ key, name, ...restField }) => (
                  <Space key={key} align="baseline"
                    style={{ display: 'flex', marginBottom: 6 }}>
                    <Form.Item name={[name, 'code']} {...restField}
                      rules={[{ required: true, message: '填代码' }]}>
                      <Input placeholder="代码" style={{ width: 96 }} />
                    </Form.Item>
                    <Form.Item name={[name, 'name']} {...restField}>
                      <Input placeholder="名称" style={{ width: 104 }} />
                    </Form.Item>
                    <Form.Item name={[name, 'volume']} {...restField}
                      rules={[{ required: true, message: '填数量' }]}>
                      <InputNumber placeholder="数量(股)" min={0} step={100}
                        style={{ width: 116 }} />
                    </Form.Item>
                    <Form.Item name={[name, 'cost_price']} {...restField}
                      rules={[{ required: true, message: '填成本价' }]}>
                      <InputNumber placeholder="成本价" min={0} step={0.001}
                        style={{ width: 108 }} />
                    </Form.Item>
                    <Form.Item name={[name, 'open_day']} {...restField}>
                      <Input placeholder="开仓日(可选)" style={{ width: 116 }} />
                    </Form.Item>
                    <Button type="text" danger icon={<DeleteOutlined />}
                      onClick={() => remove(name)} />
                  </Space>
                ))}
                <Form.Item>
                  <Button type="dashed" block icon={<PlusOutlined />}
                    onClick={() => add({ volume: 100 })}>
                    添加持仓行
                  </Button>
                </Form.Item>
              </>
            )}
          </Form.List>
        </Form>
      </Modal>

      <Collapse onChange={onCollapseChange}
        items={[
          {
            key: 'pool', label: `当前池子成员（${pool?.pool?.length ?? 0} 只，基准日 ${pool?.as_of ?? '-'}）`,
            children: (pool?.pool?.length) ? (() => {
              const heldSet = new Set(
                (summary?.positions ?? []).map((p) => p.code))
              return (
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                  {pool.pool.map((m: { code: string; name?: string }) => {
                    const held = heldSet.has(m.code)
                    return (
                      <span key={m.code} style={{
                        display: 'inline-flex', gap: 6,
                        alignItems: 'baseline', padding: '2px 10px',
                        fontSize: 13, borderRadius: 6,
                        background: held ? '#fff7e6' : '#fafafa',
                        border: held ? '1px solid #ffd591' : '1px solid #d9d9d9'
                      }}>
                        <span style={{ fontWeight: 600 }}>{m.code}</span>
                        <span style={{ color: '#555' }}>{m.name || ''}</span>
                        {held && <Tag color="orange" style={{
                          fontSize: 11, lineHeight: '16px',
                          marginInlineEnd: 0, paddingInline: 4
                        }}>仓</Tag>}
                      </span>
                    )
                  })}
                </div>
              )
            })() : (
              <Typography.Text type="secondary">
                暂无池子（执行盘前流程后生成）
              </Typography.Text>
            )
          },
          {
            key: 'cfg', label: '流程参数配置（保存后下次盘前流程生效）',
            children: cfg ? (
              <div>
                <Row gutter={12}>
                  <Col span={8}>
                    <Typography.Text type="secondary">候选域（指数成分并集）</Typography.Text>
                    <Select mode="multiple" style={{ width: '100%' }} allowClear
                      value={cfg.auto_index} options={INDEX_OPTS}
                      onChange={(v) => setCfg({ ...cfg, auto_index: v })} />
                  </Col>
                  <Col span={8}>
                    <Typography.Text type="secondary">板块过滤（空=不限）</Typography.Text>
                    <Select mode="multiple" style={{ width: '100%' }} allowClear
                      value={cfg.auto_boards} options={BOARD_OPTS}
                      onChange={(v) => setCfg({ ...cfg, auto_boards: v })} />
                  </Col>
                  <Col span={8}>
                    <Typography.Text type="secondary">选股排序键（rank_key）</Typography.Text>
                    <Select style={{ width: '100%' }} value={cfg.rank_key}
                      options={RANK_KEY_OPTS}
                      onChange={(v) => setCfg({ ...cfg, rank_key: v })} />
                  </Col>
                </Row>
                <Row gutter={12} style={{ marginTop: 8 }}>
                  <Col span={6}>
                    <Typography.Text type="secondary">虚拟资金（initial_capital）</Typography.Text>
                    {numCell(cfg.initial_capital,
                      (v) => setCfg({ ...cfg, initial_capital: v ?? 3000000 }),
                      100000, 10000)}
                  </Col>
                  <Col span={6}>
                    <Typography.Text type="secondary">池子大小（top_x）</Typography.Text>
                    {numCell(cfg.top_x, (v) => setCfg({ ...cfg, top_x: v ?? 30 }),
                      1, 1)}
                  </Col>
                  <Col span={6}>
                    <Typography.Text type="secondary">空仓重选天数（auto_idle_days）</Typography.Text>
                    {numCell(cfg.auto_idle_days,
                      (v) => setCfg({ ...cfg, auto_idle_days: v ?? 5 }), 1, 1)}
                  </Col>
                  <Col span={6}>
                    <Typography.Text type="secondary">枯竭换血线（pool_refill_min）</Typography.Text>
                    {numCell(cfg.pool_refill_min ?? 2,
                      (v) => setCfg({ ...cfg, pool_refill_min: v ?? 2 }), 1, 0)}
                  </Col>
                </Row>
                <Row gutter={12} style={{ marginTop: 8 }}>
                  <Col span={6}>
                    <Typography.Text type="secondary">衰退信号阈值（exit_need）</Typography.Text>
                    {numCell(cfg.exit_need, (v) => setCfg({ ...cfg, exit_need: v ?? 2 }),
                      1, 1)}
                  </Col>
                  <Col span={6}>
                    <Typography.Text type="secondary">gate 触发阈值（enter_th）</Typography.Text>
                    {numCell(cfg.enter_th, (v) => setCfg({ ...cfg, enter_th: v ?? 0.15 }),
                      0.01, 0.01)}
                  </Col>
                  <Col span={6}>
                    <Typography.Text type="secondary">站上均线周期（above_ma）</Typography.Text>
                    {numCell(cfg.above_ma, (v) => setCfg({ ...cfg, above_ma: v ?? 20 }),
                      5, 5)}
                  </Col>
                  <Col span={6}>
                    <Typography.Text type="secondary">榜单容量（pool_n）</Typography.Text>
                    {numCell(cfg.pool_n, (v) => setCfg({ ...cfg, pool_n: v ?? 6 }), 1, 1)}
                  </Col>
                </Row>
                <Row gutter={12} style={{ marginTop: 8 }}>
                  <Col span={6}>
                    <Typography.Text type="secondary">做T机制（t_mode）</Typography.Text>
                    <Select style={{ width: '100%' }} value={cfg.t_mode || 'off'}
                      options={T_MODE_OPTS}
                      onChange={(v) => setCfg({ ...cfg, t_mode: v })} />
                  </Col>
                  <Col span={6}>
                    <Typography.Text type="secondary">最大持仓只数（max_holdings）</Typography.Text>
                    {numCell(cfg.max_holdings ?? 3,
                      (v) => setCfg({ ...cfg, max_holdings: v ?? 3 }), 1, 1)}
                  </Col>
                  <Col span={6}>
                    <Typography.Text type="secondary">单票上限%（max_pos_pct）</Typography.Text>
                    {numCell(cfg.max_pos_pct ?? 40,
                      (v) => setCfg({ ...cfg, max_pos_pct: v ?? 40 }), 1, 1)}
                  </Col>
                  <Col span={6}>
                    <Typography.Text type="secondary">现金缓冲%（cash_reserve_pct）</Typography.Text>
                    {numCell(cfg.cash_reserve_pct ?? 1.5,
                      (v) => setCfg({ ...cfg, cash_reserve_pct: v ?? 1.5 }), 0.5, 0)}
                  </Col>
                </Row>
                <Typography.Text type="secondary" style={{
                  display: 'block', marginTop: 12, fontSize: 12
                }}>
                  交易成本（回填手续费自动计算用，与回测 Broker 同口径）
                </Typography.Text>
                <Row gutter={12} style={{ marginTop: 4 }}>
                  <Col span={4}>
                    <Typography.Text type="secondary">佣金率</Typography.Text>
                    {numCell(cfg.fee_commission_rate ?? 0.00005,
                      (v) => setCfg({ ...cfg, fee_commission_rate: v ?? 0.00005 }),
                      0.00001, 0)}
                  </Col>
                  <Col span={4}>
                    <Typography.Text type="secondary">最低佣金（元）</Typography.Text>
                    {numCell(cfg.fee_commission_min ?? 5,
                      (v) => setCfg({ ...cfg, fee_commission_min: v ?? 5 }), 1, 0)}
                  </Col>
                  <Col span={4}>
                    <Typography.Text type="secondary">印花税（仅卖出）</Typography.Text>
                    {numCell(cfg.fee_stamp_tax ?? 0.0005,
                      (v) => setCfg({ ...cfg, fee_stamp_tax: v ?? 0.0005 }),
                      0.0001, 0)}
                  </Col>
                  <Col span={4}>
                    <Typography.Text type="secondary">经手费（双边）</Typography.Text>
                    {numCell(cfg.fee_handling_fee ?? 0.0000341,
                      (v) => setCfg({ ...cfg, fee_handling_fee: v ?? 0.0000341 }),
                      0.000001, 0)}
                  </Col>
                  <Col span={4}>
                    <Typography.Text type="secondary">证管费（双边）</Typography.Text>
                    {numCell(cfg.fee_regulatory_fee ?? 0.00002,
                      (v) => setCfg({ ...cfg, fee_regulatory_fee: v ?? 0.00002 }),
                      0.000001, 0)}
                  </Col>
                  <Col span={4}>
                    <Typography.Text type="secondary">过户费（双边）</Typography.Text>
                    {numCell(cfg.fee_transfer_fee ?? 0.00001,
                      (v) => setCfg({ ...cfg, fee_transfer_fee: v ?? 0.00001 }),
                      0.000001, 0)}
                  </Col>
                </Row>
                <Space style={{ marginTop: 12 }}>
                  <Button type="primary" icon={<SaveOutlined />} loading={cfgSaving}
                    onClick={onSaveCfg}>
                    保存配置
                  </Button>
                  <Button icon={<ThunderboltOutlined />} onClick={openTplModal}>
                    从回测模板注入
                  </Button>
                </Space>
                <Modal
                  title="从回测模板注入配置"
                  open={tplOpen}
                  onCancel={() => setTplOpen(false)}
                  footer={[
                    <Button key="cancel" onClick={() => setTplOpen(false)}>取消</Button>,
                    <Button key="ok" type="primary" loading={tplApplying}
                      disabled={!tplId || !tplPreview}
                      onClick={onTplApply}>
                      确认注入
                    </Button>
                  ]}
                  width={720}
                >
                  <Space direction="vertical" style={{ width: '100%' }} size="middle">
                    <Select
                      style={{ width: '100%' }}
                      placeholder="选择回测配置模板"
                      value={tplId ?? undefined}
                      onChange={(v: number) => {
                        setTplId(v)
                        void loadTplPreview(v, tplCapital)
                      }}
                      options={tplList.map(t => ({ value: t.id, label: t.name }))}
                    />
                    <Checkbox
                      checked={tplCapital}
                      onChange={e => {
                        setTplCapital(e.target.checked)
                        void loadTplPreview(tplId, e.target.checked)
                      }}
                    >
                      同时覆盖实盘资金（默认不覆盖，实盘资金独立管理）
                    </Checkbox>
                    {tplPreview && (
                      <>
                        <Table
                          size="small"
                          rowKey="key"
                          pagination={false}
                          dataSource={tplPreview.updates}
                          columns={[
                            { title: '配置项', dataIndex: 'key', width: 180 },
                            { title: '当前值', dataIndex: 'old',
                              render: (v: unknown) => JSON.stringify(v) ?? '-' },
                            { title: '注入值', dataIndex: 'new',
                              render: (v: unknown) => (
                                <Typography.Text strong>{JSON.stringify(v)}</Typography.Text>
                              ) }
                          ] as ColumnsType<{ key: string; old: unknown; new: unknown }>}
                        />
                        {tplPreview.skipped.length > 0 && (
                          <Alert type="warning" showIcon message="以下项不注入"
                            description={tplPreview.skipped.map(s => (
                              <div key={s.key}>
                                <Typography.Text code>{s.key}</Typography.Text>：{s.reason}
                              </div>
                            ))} />
                        )}
                        <Alert type="info" showIcon
                          message="实盘独有配置（自动调度/回撤熔断/AI 简报/建议仓位）不受影响；mom 特征参数将同步到盘前/盘中/盘后特征重算，与回测同一把尺。" />
                      </>
                    )}
                  </Space>
                </Modal>
              </div>
            ) : null
          },
          {
            key: 'slip',
            label: '滑点统计（M3：实际成交价 vs 信号参考价，正=不利成本）',
            children: slip ? (
              <div>
                <Space size="large" style={{ marginBottom: 8 }}>
                  <Statistic title="样本数" value={slip.summary.n} />
                  <Statistic title="平均滑点成本"
                    value={slip.summary.avg_slip_pct != null
                      ? `${slip.summary.avg_slip_pct}%` : '-'} />
                  <Statistic title="买入均值"
                    value={slip.summary.buy_avg_slip_pct != null
                      ? `${slip.summary.buy_avg_slip_pct}%` : '-'} />
                  <Statistic title="卖出均值"
                    value={slip.summary.sell_avg_slip_pct != null
                      ? `${slip.summary.sell_avg_slip_pct}%` : '-'} />
                </Space>
                <Table
                  rowKey="fill_id" size="small"
                  dataSource={slip.rows}
                  pagination={{ pageSize: 10 }}
                  columns={[
                    { title: '代码', dataIndex: 'code', width: 90 },
                    { title: '类型', dataIndex: 'stype', width: 80 },
                    { title: '方向', dataIndex: 'side', width: 70 },
                    { title: '参考价', dataIndex: 'ref_price', width: 90, align: 'right',
                      render: (v) => v?.toFixed(3) },
                    { title: '成交价', dataIndex: 'fill_price', width: 90, align: 'right',
                      render: (v) => v?.toFixed(3) },
                    { title: '滑点%', dataIndex: 'slip_pct', width: 90, align: 'right',
                      render: (v) => (
                        <Typography.Text type={v > 0 ? 'danger' : 'success'}>
                          {v}%
                        </Typography.Text>
                      ) },
                    { title: '时间', dataIndex: 'fill_time' }
                  ]}
                  locale={{ emptyText: '暂无回填成交——回填后自动积累滑点样本' }}
                />
              </div>
            ) : <Typography.Text type="secondary">加载中...</Typography.Text>
          },
          {
            key: 'shadow',
            label: '影子运行（M3：假设每条信号都按参考价足额执行 vs 实际回填）',
            children: shadow ? (
              <Space size="large" wrap>
                <Statistic title="信号数" value={shadow.n_signals} />
                <Statistic title="已执行" value={shadow.n_filled}
                  suffix={`/ ${shadow.n_signals}`} />
                <Statistic title="执行率"
                  value={shadow.fill_rate != null
                    ? `${(shadow.fill_rate * 100).toFixed(1)}%` : '-'} />
                <Statistic title="影子已实现盈亏（按参考价）"
                  valueStyle={{ color: shadow.shadow_pnl >= 0 ? '#3f8600' : '#cf1322' }}
                  value={fmtMoney(shadow.shadow_pnl)} />
                <Statistic title="实际已实现盈亏（回填口径）"
                  valueStyle={{ color: shadow.actual_pnl >= 0 ? '#3f8600' : '#cf1322' }}
                  value={fmtMoney(shadow.actual_pnl)} />
                <Statistic title="执行差（实际-影子）"
                  valueStyle={{ color: shadow.gap_pnl >= 0 ? '#3f8600' : '#cf1322' }}
                  value={fmtMoney(shadow.gap_pnl)} />
                <Statistic title="影子天数" value={shadow.days} />
              </Space>
            ) : <Typography.Text type="secondary">加载中...</Typography.Text>
          },
          {
            key: 'ready',
            label: 'M4 小资金实盘就绪检查',
            children: ready ? (
              <div>
                <Alert
                  type={ready.ready ? 'success' : 'warning'} showIcon
                  style={{ marginBottom: 8 }}
                  message={ready.ready
                    ? '全部通过——可按 M4 流程以极小资金（5 万级）开始跟单灰度'
                    : '存在未通过项——建议先补齐再上小资金'}
                />
                {ready.items.map((it) => (
                  <Space key={it.key} size={8} style={{ display: 'flex', marginBottom: 4 }}>
                    {it.ok
                      ? <CheckCircleOutlined style={{ color: '#3f8600' }} />
                      : <CloseCircleOutlined style={{ color: '#cf1322' }} />}
                    <Typography.Text strong>{it.label}</Typography.Text>
                    <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                      {it.detail}
                    </Typography.Text>
                  </Space>
                ))}
              </div>
            ) : <Typography.Text type="secondary">加载中（含行情源探测，约 1-2 秒）...</Typography.Text>
          }
        ]}
      />

      <Modal
        title={`回填成交：${fillTarget?.code ?? ''} ${fillTarget?.name ?? ''} ${fillTarget?.stype ?? ''}`}
        open={!!fillTarget}
        onOk={onFill}
        onCancel={() => setFillTarget(null)}
        okText="确认回填"
      >
        <Space direction="vertical" style={{ width: '100%' }}>
          <Typography.Text type="secondary">
            {fillTarget?.reason}｜建议金额 {fillTarget?.suggest_amount != null
              ? fmtMoney(fillTarget.suggest_amount) : '-'}
            ｜参考价 {fillTarget?.ref_price != null ? fillTarget.ref_price.toFixed(3) : '-'}
          </Typography.Text>
          <Typography.Text>成交价：</Typography.Text>
          <InputNumber
            min={0.001} step={0.001} style={{ width: '100%' }}
            value={fillPrice}
            onChange={(v) => {
              setFillPrice(v)
              // 买入类信号：成交价变动 -> 股数按「建议金额÷成交价」自动重算
              // （100股取整，保证资金约等于建议金额、不超总预算）；
              // 重算后仍可手改，以实际成交为准
              const isBuy = !!fillTarget && ['开仓', '加仓'].includes(fillTarget.stype)
              if (isBuy && v && fillTarget?.suggest_amount) {
                const vol = Math.floor(fillTarget.suggest_amount / v / 100) * 100
                setFillVolume(vol >= 100 ? vol : null)
              }
            }}
            placeholder="实际成交价（买入类改动后股数自动按建议金额重算）" />
          <Typography.Text>数量（股）：</Typography.Text>
          <InputNumber
            min={100} step={100} style={{ width: '100%' }}
            value={fillVolume} onChange={(v) => setFillVolume(v)}
            placeholder="实际成交数量" />
          {fillTarget && ['开仓', '加仓'].includes(fillTarget.stype)
            && fillPrice != null && fillVolume != null && (
            <Typography.Text
              type={fillPrice * fillVolume > (fillTarget.suggest_amount ?? Infinity)
                ? 'warning' : 'secondary'}
              style={{ fontSize: 12 }}>
              预计金额 {fmtMoney(fillPrice * fillVolume)}｜建议金额 {fillTarget.suggest_amount != null
                ? fmtMoney(fillTarget.suggest_amount) : '-'}
              {fillTarget.suggest_amount != null
                && fillPrice * fillVolume > fillTarget.suggest_amount
                ? '｜超出预算（价格高于参考价），请确认是否按实际成交回填' : '｜预算内'}
            </Typography.Text>
          )}
          <Typography.Text>手续费（元）：</Typography.Text>
          <InputNumber
            min={0} step={1} style={{ width: '100%' }}
            value={fillFee ?? undefined} onChange={(v) => setFillFee(v)}
            placeholder="留空 = 按交易成本费率自动计算" />
          <Typography.Text type="secondary" style={{ fontSize: 12 }}>
            参考股数预填：买入=建议金额÷参考价（100股取整）；卖出=按当前虚拟持仓
            （清仓/止损=全部，减仓/做T=按比例）。买入类修改成交价后，股数自动按
            「建议金额÷成交价」重算（不超预算），仍可手改——请以实际成交为准。
            手续费留空时按配置费率自动计算（佣金+印花税+经手/证管/过户），
            买入费用摊入持仓成本价（与券商摊薄成本同口径）。
          </Typography.Text>
        </Space>
      </Modal>
    </Space>
  )
}
